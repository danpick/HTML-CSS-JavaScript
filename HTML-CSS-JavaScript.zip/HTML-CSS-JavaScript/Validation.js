function validateForm() {
var result = true;
var msg="";

var re11digit=/^\d{11}$/ //regular expression defining an 11 digit number

if (document.MobilePhoneTopUp.name.value=="") {
msg+="You must enter your name \n";
document.MobilePhoneTopUp.name.focus();
document.getElementById('name').style.color="red";
result = false;
}

if (document.MobilePhoneTopUp.network.value=="") {
msg+="You must enter your mobile network \n";
document.MobilePhoneTopUp.network.focus();
document.getElementById('network').style.color="red";
result = false;
}

if (document.MobilePhoneTopUp.mobile_no.value.search(re11digit)==-1) { //if match failed
msg+="You must enter an 11 digit mobile number \n";
document.MobilePhoneTopUp.mobile_no.focus();
document.getElementById('mobile_no').style.color="red";
result = false;
}

for (var i=0;i < document.MobilePhoneTopUp.optAmount.length; i++)
{
if (document.MobilePhoneTopUp.optAmount[i].checked)
	{
	var amount = document.MobilePhoneTopUp.optAmount[i].value;
	}
}
//alert(amount); //for testing

var radio_ok = confirm("You have chosen the top-up amount as " + amount + " do you wish to continue?");
if (radio_ok == false){ //and user hasn't confirmed
	return false;
}

if(msg==""){
return result;
}
{
alert(msg)
return result;
}
}