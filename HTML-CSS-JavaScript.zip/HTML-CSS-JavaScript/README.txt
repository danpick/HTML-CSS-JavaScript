#HTML-CSS-JavaScript example

A very simple validated web-page that acts as an example of some of the web programming skills that I've used over the years. CSS and Javascript are external, demonstrating re-usability and maintainability. CSS used can be toggled between corporate and accessible, and javscript demonstrates some good techniques such as regular expressions.

I've coded with these technologies to a much more advanced level whist working for Gala Group (as part of a Lotus Domino project for an invoice processing workflow system) but will not post this on GitHub as I don't want to expose Gala's intellectual property.

any questions, email me at danpick77@gmail.com